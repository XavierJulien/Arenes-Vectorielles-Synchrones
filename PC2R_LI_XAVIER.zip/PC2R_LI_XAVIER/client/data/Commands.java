package data;


public enum Commands {
	clock,
	anticlock,
	thrust
}
